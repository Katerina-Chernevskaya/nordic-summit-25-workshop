from promptflow import tool

@tool
def has_search_queries(params: dict) -> bool:
    return True if len(params.get('search_queries', [])) > 0 else False