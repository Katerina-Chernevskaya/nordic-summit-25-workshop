from promptflow import tool
from typing import Optional, List

@tool
def extract_search_queries(params: dict) -> List[str]:
    return params.get('search_queries', [])