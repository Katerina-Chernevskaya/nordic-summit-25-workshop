from opencensus.ext.azure.log_exporter import AzureLogHandler
import logging
import json
from promptflow import tool
from datetime import datetime

# Configure Application Insights Logger
logger = logging.getLogger("PromptFlowLogger")
logger.addHandler(AzureLogHandler(connection_string="InstrumentationKey=6a890771-714c-4449-99c8-6f1fb71750c2;IngestionEndpoint=https://francecentral-1.in.applicationinsights.azure.com/;LiveEndpoint=https://francecentral.livediagnostics.monitor.azure.com/;ApplicationId=2df8b9c8-37f1-4570-9866-6f92cb92a6c7"))
logger.setLevel(logging.INFO)

# Static query ID for telemetry filtering
STATIC_QUERY_ID = "eppc25-telemetry-log"

@tool
def main(
    question: str,
    search_queries: str,
    get_search_results: str,
    answer_generation: str
):
    print(question + str(type(question)))
    # Generate session ID based on the current timestamp
    session_id = datetime.utcnow().strftime("%y%m%d-%H%M%S")

    # Aggregate telemetry data
    telemetry_data = {
        "static_query_id": STATIC_QUERY_ID,
        "session_id": session_id,
        "question": question,
        "search_queries": search_queries,
        "get_search_results": get_search_results,
        "answer_generation": answer_generation,
    }

    # Serialize telemetry data as JSON string with ensure_ascii=False
    serialized_telemetry = json.dumps(telemetry_data)#, ensure_ascii=False)

    # Log telemetry with explicit UTF-8 encoding
    logger.info("Aggregated Flow Outputs", extra={"custom_dimensions": json.loads(serialized_telemetry)})

    return json.loads(serialized_telemetry)