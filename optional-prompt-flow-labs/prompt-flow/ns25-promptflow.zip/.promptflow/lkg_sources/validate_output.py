from promptflow import tool
import json

@tool
def validate_output(qu_output: str) -> dict:
    '''
    Receives a JSON input of the form:
        {
            "search_queries": []
        }
    '''
    return json.loads(qu_output)