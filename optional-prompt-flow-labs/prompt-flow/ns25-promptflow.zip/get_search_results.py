import re
from promptflow import tool
from typing import List
import json

@tool
def get_search_results(search_result: List[List[dict]]) -> List[dict]:
    
    MAX_RESULTS = 5  # maximum number of search results / document chunks
    
    # function to clean up extra line breaks
    clear_text = lambda text: re.sub('\n{1,}', '. ', text)

    # Flattening nested lists
    extended_search_result = [
        item for sublist in search_result for item in sublist
    ]

    # No matching results were found
    if len(extended_search_result) == 0:
        return {'docs': [], 'queries': [], 'links': {}}

    # Retain only elements with unique chunk_id values
    unique_chunk_ids = set()  # A set used to store unique chunk_id entries
    output = []  # A list used to store only unique elements


    # Filtering to retain only unique chunk_id values
    for idx, row in enumerate(extended_search_result, start=1):
        chunk_id = row.get('additional_fields', {}).get('chunk_id')
        if chunk_id not in unique_chunk_ids:
            unique_chunk_ids.add(chunk_id)
            output.append({
                'doc_id': f'doc{idx}',  # Add the docX field
                'content': clear_text(row.get('text')),
                'source': clear_text(row.get('metadata')),
                'original_score': row.get('score'),
                'reranked_score': None  # Explicitly mark the field as missing
            })

    # Restrict the results to MAX_RESULTS
    limited_output = output[:MAX_RESULTS]
    
    # Construct the links field in the format {"[docX]": "source"}
    links = {
        f"[{item['doc_id']}]" : item['source']
        for item in limited_output
    }

    # Returning the resulting final structure
    return {
        'docs': limited_output,
        'queries': [],  # Keep it empty, just like in the original
        'links': json.dumps(links, ensure_ascii=False)  # JSON string
    }